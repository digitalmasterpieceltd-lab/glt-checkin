-- ================================================================
-- GLT SAFEPASS — FINAL PRODUCTION SQL
-- Run this in Supabase → SQL Editor
-- Safe to run on existing database (uses IF NOT EXISTS / ADD COLUMN IF NOT EXISTS)
-- ================================================================

-- 1. Stewards table — add photo column
ALTER TABLE stewards ADD COLUMN IF NOT EXISTS photo_url TEXT;

-- 2. Parents table — add photo column  
ALTER TABLE parents ADD COLUMN IF NOT EXISTS photo_url TEXT;

-- 3. Children table — add photo column
ALTER TABLE children ADD COLUMN IF NOT EXISTS photo_url TEXT;

-- 4. Create storage bucket for photos (run this too)
-- Go to Supabase → Storage → New bucket → Name: "glt-photos" → Public: ON
-- Then run these policies:

-- Storage bucket policy (allows public read + authenticated write)
-- NOTE: Create the bucket manually first in Supabase Dashboard → Storage
-- Then these policies will work:

-- Allow public access to view photos
INSERT INTO storage.buckets (id, name, public)
VALUES ('glt-photos', 'glt-photos', true)
ON CONFLICT (id) DO UPDATE SET public = true;

-- Storage RLS policies
CREATE POLICY IF NOT EXISTS "Public read glt-photos"
ON storage.objects FOR SELECT
USING (bucket_id = 'glt-photos');

CREATE POLICY IF NOT EXISTS "Anyone can upload glt-photos"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'glt-photos');

CREATE POLICY IF NOT EXISTS "Anyone can update glt-photos"
ON storage.objects FOR UPDATE
USING (bucket_id = 'glt-photos');

CREATE POLICY IF NOT EXISTS "Anyone can delete glt-photos"
ON storage.objects FOR DELETE
USING (bucket_id = 'glt-photos');

-- 5. Verify all columns
SELECT 
  table_name,
  column_name,
  data_type
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name IN ('stewards','parents','children','sessions')
ORDER BY table_name, ordinal_position;
