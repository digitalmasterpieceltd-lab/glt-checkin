-- ================================================================
-- GLT SAFEPASS — PHASE 3: CHURCH SESSIONS & REPORTING
-- Run in Supabase → SQL Editor
-- ================================================================

-- 1. Church sessions table (Sunday service / Bible study / etc.)
CREATE TABLE IF NOT EXISTS church_sessions (
  id            uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  date          date NOT NULL DEFAULT CURRENT_DATE,
  program_type  text NOT NULL,   -- 'sunday_1st' | 'sunday_2nd' | 'bible_study' | 'youth' | 'special'
  custom_name   text,            -- used when program_type = 'special'
  opened_by     uuid REFERENCES stewards(id),
  opened_at     timestamptz DEFAULT now(),
  closed_at     timestamptz,
  notes         text,
  status        text DEFAULT 'open'  -- 'open' | 'closed'
);

-- 2. Link check-in sessions to church sessions
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS church_session_id uuid REFERENCES church_sessions(id);

-- 3. RLS
ALTER TABLE church_sessions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "allow_all" ON church_sessions;
CREATE POLICY "allow_all" ON church_sessions FOR ALL USING (true) WITH CHECK (true);

-- 4. Useful index for date queries
CREATE INDEX IF NOT EXISTS idx_church_sessions_date ON church_sessions(date DESC);
CREATE INDEX IF NOT EXISTS idx_sessions_church_session ON sessions(church_session_id);
CREATE INDEX IF NOT EXISTS idx_sessions_checkin_date ON sessions(checkin_time DESC);

-- 5. Confirm
SELECT table_name FROM information_schema.tables
WHERE table_schema = 'public' ORDER BY table_name;
