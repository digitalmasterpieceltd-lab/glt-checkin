-- ================================================================
-- GLT CHILDREN'S CHECK-IN SYSTEM — v5 DATABASE UPGRADE
-- Run this in Supabase → SQL Editor
-- ================================================================

-- 1. ADD NEW COLUMNS TO EXISTING TABLES
-- (safe to run even if columns already exist)

alter table children
  add column if not exists medication text,
  add column if not exists feeding_notes text,
  add column if not exists care_notes text;

alter table sessions
  add column if not exists checkin_by uuid,
  add column if not exists checkout_by uuid,
  add column if not exists belongings text;

-- 2. CREATE STEWARDS TABLE

create table if not exists stewards (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  password text not null,
  role text not null default 'steward',  -- 'admin' or 'steward'
  created_at timestamptz default now()
);

-- 3. ENABLE ROW LEVEL SECURITY ON STEWARDS

alter table stewards enable row level security;

create policy "allow_all" on stewards
  for all using (true) with check (true);

-- 4. VERIFY — you should see all 4 tables listed
select table_name from information_schema.tables
where table_schema = 'public'
order by table_name;
