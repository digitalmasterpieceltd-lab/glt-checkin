-- ================================================================
-- GLT CHECK-IN SYSTEM — FULL DATABASE RESET & UPGRADE
-- Run this in Supabase → SQL Editor
-- This upgrades the stewards table to support full user profiles
-- WARNING: This CLEARS all existing steward accounts
-- ================================================================

-- Step 1: Drop and recreate stewards table with full profile fields
drop table if exists stewards cascade;

create table stewards (
  id            uuid default gen_random_uuid() primary key,
  name          text not null,
  username      text not null unique,
  password      text not null,
  role          text not null default 'steward',  -- 'superadmin' | 'admin' | 'steward'
  phone         text,
  email         text,
  address       text,
  emergency_contact text,
  emergency_phone   text,
  is_active     boolean default true,
  created_at    timestamptz default now(),
  last_login    timestamptz
);

-- Step 2: Ensure children and sessions have all needed columns
alter table children
  add column if not exists medication   text,
  add column if not exists feeding_notes text,
  add column if not exists care_notes   text;

alter table sessions
  add column if not exists checkin_by   uuid,
  add column if not exists checkout_by  uuid,
  add column if not exists belongings   text;

-- Step 3: RLS policies
alter table stewards enable row level security;
drop policy if exists "allow_all" on stewards;
create policy "allow_all" on stewards for all using (true) with check (true);

-- Step 4: Confirm all tables exist
select table_name, 
  (select count(*) from information_schema.columns c where c.table_name = t.table_name and c.table_schema = 'public') as column_count
from information_schema.tables t
where table_schema = 'public'
order by table_name;
